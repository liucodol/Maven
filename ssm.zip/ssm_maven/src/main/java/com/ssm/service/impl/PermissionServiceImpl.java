package com.ssm.service.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.ssm.dao.IPermissionDao;
import com.ssm.dao.IRolesDao;
import com.ssm.dao.IUserDao;
import com.ssm.pojo.Permission;
import com.ssm.pojo.Roles;
import com.ssm.pojo.User;
import com.ssm.service.IPermissionService;



@Service
public class PermissionServiceImpl implements IPermissionService{
	
	@Resource
	private IPermissionDao permissionDao;
	@Resource
	private IUserDao userDao;
	@Resource
	private IRolesDao rolesDao;
	
	public Set<String> findByPermissions(String username){
		Set<String> result = new HashSet<>();
		User user = userDao.findByUserName(username);		
		List<Roles>roles = rolesDao.findAll(user.getId());
		List<Permission> permission = new ArrayList<>();
		
		for (Roles role : roles) {
			List<Permission> rps = permissionDao.findByPermissions(role.getId());
			permission.addAll(rps);
		}
		
		for(Permission Per : permission) {
			result.add(Per.getPermissionname());
		}
		
		/*Roles roles = rolesDao.findAll(user.getId());*/
		/*permissionDao.findByPermissions(roles.getId());*/
		return result;
	}
	
}
