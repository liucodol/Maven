package com.ssm.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.ssm.dao.IPermissionDao;
import com.ssm.service.IPermissionService;



@Service
public class PermissionServiceImpl implements IPermissionService{
	@Resource
	private IPermissionDao permissionDao;
	
	
	
}
