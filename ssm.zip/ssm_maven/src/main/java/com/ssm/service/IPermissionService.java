package com.ssm.service;

public interface IPermissionService {
	
	
	
	

}
