package com.ssm.service;

import java.util.List;
import java.util.Set;

public interface IPermissionService {

	Set<String> findByPermissions(String username);
	
	
	
	

}
