package com.ssm.service;

import java.util.List;
import java.util.Set;

import com.ssm.pojo.Permission;

public interface IPermissionService {

	Set<String> findByPermissions(String username);

	Set<String> findAll(int user_id);

	Permission findByname(String permissionname);

	void savePers(int user_id, int id);

	boolean delete(int id);

	List<Permission> findByNameAll(int id);

	



	

	

	
	
	
	
	

}
