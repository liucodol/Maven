package com.ssm.service.impl;

import java.security.Permissions;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.shiro.authz.annotation.RequiresRoles;
import org.springframework.stereotype.Service;

import com.ssm.dao.IUserDao;
import com.ssm.pojo.User;

import com.ssm.service.IUserService;

@Service("UserService")
public class UserServiceImpl implements IUserService{
	@Resource
	private IUserDao userDao;
	
	 /**  
     *��¼  
     */ 
	/*public User login(Map<String, String> map) {
		// TODO Auto-generated method stub
		return userDao.login(map);
	}*/
	public User login(String username) {
		// TODO Auto-generated method stub
		return userDao.login(username);
	}
	
	/**  
     *根据用户名查出所有的角色
     */ 
	
	 /**  
	     *根据角色名查出所拥有的权限
	     */ 
	
	 
	 
	 /**  
     * ע��  
     */ 
	public User selectUser(Map<String, String> map) {
		// TODO Auto-generated method stub
		return userDao.selectUser(map);
	}
	
	public void insertUser(User user) {  
		userDao.insertUser(user);  
    } 
	 /**  
     * ��ѯUser��ȫ������  
     */ 
	
    public List<User> findAll() {  
        List<User> findAllList = userDao.findAll();  
        return findAllList;  
    } 
    /**  
     * ����µ��û�  
     */
    public void addUser(User user) {  
		userDao.addUser(user); 		
    }
    /**  
     * ɾ���û�  
     */
    public Boolean delete(int id) {  
        return userDao.delete(id);  
          
    }
    /**  
     * �޸��û�  
     */
    public User findById(int id) {
		// TODO Auto-generated method stub
		return userDao.findById(id);
	}
    public Boolean update(User user) {  
        return userDao.update(user);  
          
    }
    /**  
     * ��ѯUser��ȫ������  
     */ 
    public List<User> keywordfindAll(User user) {  
        List<User> findAllList = userDao.keywordfindAll(user);  
        return findAllList;  
    } 
    
    
    public User findByUserName(String username) {
		return userDao.findByUserName(username);
    	
    }
    
}
