package com.ssm.service.impl;

import java.util.Set;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.ssm.dao.IRolesDao;
import com.ssm.dao.IUserDao;
import com.ssm.pojo.User;
import com.ssm.service.IRolesService;



@Service
public class RolesServiceImpl implements  IRolesService{
	@Resource
	private IRolesDao rolesDao;
	@Resource
	private IUserDao userDao;
	
	public Set<String> findByRolesName(String username){
		User user = userDao.findByUserName(username); 
		return rolesDao.findByRolesName(user.getId());
		
		
	}
	
	
}
