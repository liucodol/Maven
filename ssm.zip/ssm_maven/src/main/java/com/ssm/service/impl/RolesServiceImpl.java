package com.ssm.service.impl;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.ssm.dao.IRolesDao;
import com.ssm.dao.IUserDao;
import com.ssm.pojo.Roles;
import com.ssm.pojo.User;
import com.ssm.service.IRolesService;



@Service
public class RolesServiceImpl implements  IRolesService{
	@Resource
	private IRolesDao rolesDao;
	@Resource
	private IUserDao userDao;
	
	public Set<String> findByRoles(String username){
		Set<String> result = new HashSet<>();
		User user = userDao.findByUserName(username);
		
		List<Roles>roles = rolesDao.findByRoles(user.getId());
		for (Roles role : roles) {
			result.add(role.getRolesname());
		}
		return result;
		
		
	}
//	   给注册成功的用户添加角色（user）	
	public void insetRoles(int id) {
		rolesDao.insetRoles(id);
	}
//	删除用户时将拥有的角色也删除
	public boolean delete(int id) {
	  
	        return rolesDao.delete(id);  
	          
	
	}
	public Roles findById(String rolesname) {
		return rolesDao.findById(rolesname);
		
	}
	public void update(int user_id, int id) {
		rolesDao.update(user_id,id);
	}
	
	
	
	
}
