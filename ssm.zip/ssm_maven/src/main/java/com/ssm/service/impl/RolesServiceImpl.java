package com.ssm.service.impl;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.ssm.dao.IRolesDao;
import com.ssm.dao.IUserDao;
import com.ssm.pojo.Roles;
import com.ssm.pojo.User;
import com.ssm.service.IRolesService;



@Service
public class RolesServiceImpl implements  IRolesService{
	@Resource
	private IRolesDao rolesDao;
	@Resource
	private IUserDao userDao;
	
	public Set<String> findByRoles(String username){
		Set<String> result = new HashSet<>();
		User user = userDao.findByUserName(username);
		/*rolesDao.findByRoles(user.getId())*/
		List<Roles>roles = rolesDao.findByRoles(user.getId());
		for (Roles role : roles) {
			result.add(role.getRolesname());
		}
		return result;
		
		
	}
	
	
}
