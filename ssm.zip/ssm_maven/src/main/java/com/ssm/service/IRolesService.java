package com.ssm.service;

import java.util.Set;

public interface IRolesService {

	Set<String> findByRolesName(String username);
	
	
	
	

}
