package com.ssm.service;

import java.util.List;
import java.util.Set;

import com.ssm.pojo.Roles;

public interface IRolesService {

	Set<String> findByRoles(String username);
//	   给注册成功的用户添加角色（user）
	void insetRoles(int id);
//	删除用户时将拥有的角色也删除
	boolean delete(int id);
	
	Roles findById(String rolesname);
	
	void update(int user_id, int id);
	
	

	

	

	
	
	
	
	

}
