package com.ssm.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.ssm.pojo.User;


public interface IUserService {
	/**
     * ��¼
     *
     * @param map
     * @return
     */
    public User login(String username);
    /**
     * ע��
     *
     * @param username
     * @return
     */
	public User selectUser(Map<String, String> map);
	public void insertUser(User user);
	 /**
     * ��ѯ���е��û�
     *
     * @param username
     * @return
     */
	public List<User> findAll();
	 /**
     * ����µ��û�
     *
     * @param username
     * @return
     */
	public void addUser(User user);
	/**
     * ɾ���û�
     *
     * @param username
     * @return
     */
	public Boolean delete(int id);	
	/**
     * �޸��û�
     *
     * @param username
     * @return
     */
	public User findById(int id);
	public Boolean update(User user);
	/**
     * ��ѯ���е��û�
     *
     * @param username
     * @return
     */
	
	public List<User> keywordfindAll(User user);
	
	/**
     * 根据当前用户名查询用户
     *
     * @param username
     * @return
     */
	public User findByUserName(String username);
	
	
	
	
	
	

	

	
}
