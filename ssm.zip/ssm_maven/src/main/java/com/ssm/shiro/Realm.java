package com.ssm.shiro;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.LockedAccountException;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.util.ByteSource;
import org.springframework.beans.factory.annotation.Autowired;

import com.ssm.pojo.User;
import com.ssm.service.IPermissionService;
import com.ssm.service.IRolesService;
import com.ssm.service.IUserService;



public class Realm extends AuthorizingRealm{
	@Autowired
	private IUserService userService;
	@Autowired
	private IRolesService rolesService;
	@Autowired
	private IPermissionService permissionService;
	
	/**
	 * 认证
	 *
	 * @param authenticationToken
	 * @return
	 * @throws AuthenticationException
	 */
	@Override
	protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
		// 1、把AuthenticationToken转换为UsernamePasswordToken
		UsernamePasswordToken usernamePasswordToken = (UsernamePasswordToken) token;
		// 2、从UsernamePasswordToken中获取用户名
		String username = usernamePasswordToken.getUsername();
		// 3、根据用户名获取数据库的用户信息
		User shiroUsers = userService.login(username);
		System.out.println(shiroUsers);
		// 4.如果用户不存在，抛出用户不存在异常
		if (shiroUsers == null) {
			throw new UnknownAccountException("用户不存在！");// 没找到帐号
		}
		// 5、根据用户信息，抛出用户锁定异常
		if (Boolean.TRUE.equals(false)) {
			throw new LockedAccountException("帐号锁定"); // 帐号锁定
		}
		// 6、根据用户情况，构造AuthenticationInfo并返回
		// 以下数据是从数据库获取的
		// a、principal用户信息，user实体
		Object principal = shiroUsers.getUsername();
		// b、用户密码
		Object credentials = shiroUsers.getPassword();
//				获取盐
		String salt=shiroUsers.getSalt();
		// c、当前realm的getname()
		String realmName = getName();
		// d、盐值，
		ByteSource credentialsSalt = ByteSource.Util.bytes(salt);
		SimpleAuthenticationInfo info = null;
//				info = new SimpleAuthenticationInfo(principal, credentials, credentialsSalt, realmName);
		info=new SimpleAuthenticationInfo(shiroUsers,credentials,credentialsSalt,realmName);
		return info;
	}
	/**
	 * 
	 * 授权
	 *
	 * @param principalCollection
	 * @return
	 */
	@Override
	protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
		// 1、从PrincipalCollection中获取登录的用户信息
				User user =  (User) principals.getPrimaryPrincipal();
		
				// 2、创建SimpleAuthorizationInfo对象
				SimpleAuthorizationInfo authorizationInfo = new SimpleAuthorizationInfo();
				// 3、获取并设置role
				/*Set<String> roles= rolesService.findByRolesName(user.getUsername());
				authorizationInfo.setRoles(roles);*/
				String roles = "manager";/*userService.findRoles(user.getUsername());*/
				authorizationInfo.addRole(roles);
				// 4、获取并设置Permissions
				String permissions = "query";/*userService.findPermissions(user.getUsername());*/
				authorizationInfo.addStringPermission(permissions);
				
				return authorizationInfo;
		
	}

}
