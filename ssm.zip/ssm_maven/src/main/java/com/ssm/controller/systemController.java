package com.ssm.controller;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@org.springframework.stereotype.Controller
public class systemController {
	@RequestMapping(value="/{page}")
	private ModelAndView system(ModelAndView mv,@PathVariable("page") String page) {
		mv.setViewName(page);
		
		return mv;
	}
}
