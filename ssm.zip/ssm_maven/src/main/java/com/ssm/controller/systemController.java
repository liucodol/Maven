package com.ssm.controller;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@org.springframework.stereotype.Controller
public class systemController {
	@RequestMapping(value="/{page}")
	private String yilan(Model model,@PathVariable("page") String page) {
		return page;
	}
}
