package com.ssm.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.LockedAccountException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.apache.shiro.crypto.SecureRandomNumberGenerator;
import org.apache.shiro.crypto.hash.SimpleHash;
import org.apache.shiro.subject.Subject;
import org.apache.shiro.util.ByteSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ssm.pojo.Roles;
import com.ssm.pojo.URP;
import com.ssm.pojo.User;
import com.ssm.service.IPermissionService;
import com.ssm.service.IRolesService;
import com.ssm.service.IUserService;

import cn.itcast.estore.utils.MD5Utils;

@Controller
@RequestMapping("/user")
public class userController {
		
	@Resource    
	private IUserService userService;
	@Resource    
	private IRolesService rolesService;
	@Resource    
	private IPermissionService permissionService;
	
  /**     
   * * 用户登录         
   * *      
   * * @param req     
   * * @param mv     
   * * @return     
   * */
   @RequestMapping("/login")
    public ModelAndView login(HttpServletRequest req,User user, ModelAndView mv,HttpSession session) {
     /*Map<String, String> map = new HashMap<String, String>();
     session.removeAttribute("message");
     try {
    	 if (user != null) {
    		 map.put("username", user.getUsername());       
    		 map.put("password", user.getPassword());
    		 User users = userService.login(map);
    		 String password = MD5Utils.md5(user.getPassword());
    		 System.out.println(password);
    		 if(users!=null) {
    			 if(users.getPassword().equals(password)) {
    				 //登录成功进入首页
    				session.setAttribute("message", user);
    				 mv.setViewName("home");
    			 }else {
//    					密码错误
    				 mv.addObject("message", "密码错误！！！");
    				 mv.setViewName("login");
    			 }	  
    		 }else {
//    			 告诉用户不存在
    			 mv.addObject("message", "用户不存在，请前往注册");
    			 mv.setViewName("login");
    		 }
    		 
    	 }else {
//    		用户名或者密码不能为空
    		 mv.addObject("message", "用户名或者密码不能为空，请重新输入");
    		 mv.setViewName("login");
    	 }
		
	} catch (Exception e) {
		// TODO: handle exception
	}*/
	   mv.addObject("user", user);
	   Subject subject = SecurityUtils.getSubject();
	/*   if (subject.isAuthenticated()) {*/
		
		UsernamePasswordToken token = new UsernamePasswordToken(user.getUsername(),user.getPassword());
		// 记住我
	/*	token.setRememberMe(true);*/
		mv.setViewName("home");
		try {			
			subject.login(token);
		} catch (UnknownAccountException e) {
			e.printStackTrace();
			mv.addObject("message", "用户名错误！");
			mv.setViewName("login");
		} catch (IncorrectCredentialsException e) {
			e.printStackTrace();
			mv.addObject("message", "密码错误！");
			mv.setViewName("login");
		} catch (LockedAccountException e) {
			e.printStackTrace();
			mv.addObject("message", "用户被锁定！");
			mv.setViewName("login");
		} catch (AuthenticationException  e) {
			e.printStackTrace();
			mv.addObject("message", "登录失败！");
			mv.setViewName("login");
		}
	/*}*/
    		 
        return mv;
}
   /**     
    * * 用户注册   
    * *      
    * * @param req     
    * * @param mv     
    * * @return     
    * */
   @RequestMapping("/register")
   public ModelAndView register(HttpServletRequest req,User user, ModelAndView mv){	   
	   Map<String, String> map = new HashMap<String, String>();
		//加密操作
		 String salt = new SecureRandomNumberGenerator().nextBytes().toString();	// 盐
		// 加盐次数	
		 int times = 2;	
			// MD5 加密
			String algorithmName = "md5";	
			// 加密 密码
			String encodedPassword = new SimpleHash(algorithmName, user.getPassword(), salt, times).toString();
	   map.put("username", req.getParameter("username"));       
/*	   map.put("password", encodedPassword);*/
	   
	   
	   User users = userService.selectUser(map);
	   
	   if (users != null) {
		   if(user.getUsername().equals(users.getUsername())) {		   
			   mv.addObject("error", "用户名已存在！");
			   mv.setViewName("register");
			   
		   }    
	   }else {
		   user.setPassword(encodedPassword);
		   user.setSalt(salt);
		   mv.addObject("success", "用户注册成功！");
		   userService.insertUser(user);
//		   给注册成功的用户添加角色（user）
		   User new_user = userService.selectUser(map);
		   rolesService.insetRoles(new_user.getId());
		   
		   mv.setViewName("register");
	   }	  
	   return mv;
   } 
   
  /**  
    *  获取所有用户列表  
    * @param request  
    * @return  
    */ 
   @RequestMapping("/Manage")  
   public ModelAndView userManage(@RequestParam(required=true,defaultValue="1") Integer page, HttpServletRequest request,ModelAndView mv){  
	   Subject subject =  SecurityUtils.getSubject(); 
	   
	   if(subject.hasRole("manager")){
		   
		   PageHelper.startPage(page, 3);
		   List<User> lists=userService.findAll();
		   PageInfo<User> p=new PageInfo<User>(lists);
		   
		   mv.addObject("page", p);
		   mv.addObject("userList", lists);
		   mv.setViewName("manage");
	   }else {
		   mv.setViewName("error");	   
		   
	}
	   return mv;
   } 
   
   /**  
             * 添加新用户  
    * @param request  
    * @return  
    */  
   @RequestMapping("/adduser")
   public ModelAndView addUser(HttpServletRequest req,User user, ModelAndView mv){	   

	
	   Map<String, String> map = new HashMap<String, String>();
	 //加密操作
		 String salt = new SecureRandomNumberGenerator().nextBytes().toString();	// 盐
		// 加盐次数	
		 int times = 2;	
			// MD5 加密
			String algorithmName = "md5";	
			// 加密 密码
			String encodedPassword = new SimpleHash(algorithmName, user.getPassword(), salt, times).toString();
	   map.put("username", req.getParameter("username"));       
	   map.put("password", encodedPassword);
	   User users = userService.selectUser(map);	   
	   if (users != null) {
		   if(user.getUsername().equals(users.getUsername())) {		   
			   mv.addObject("message", "用户名已存在！");
			   mv.setViewName("adduser");			   
		   }    
	   }else {
		   user.setPassword(encodedPassword);
		   user.setSalt(salt);
		   mv.addObject("message", "用户添加成功！");
		   userService.addUser(user);	
//		   给新添加的用户添加角色（user）
		   User new_user = userService.selectUser(map);
		   rolesService.insetRoles(new_user.getId());
		   
		   mv.setViewName("adduser");
	   }	

	   
	   return mv;
   }
   /**  
    * 删除用户  
*  @param id  
   * @param request  
   * @param response 
*/  
   @RequestMapping("delUser")
   public void delUser(int id,HttpServletRequest request,HttpServletResponse response){  

	
		   String result = "{\"result\":\"error\"}"; 	   
       if(userService.delete(id)){  
           result = "{\"result\":\"success\"}";  
       }  
       response.setContentType("application/json");  
       try {  
           PrintWriter out = response.getWriter();  
           out.write(result);  
       } catch (IOException e) {  
           e.printStackTrace();  
       }         

		
	
   }  
   /**  
    * 修改用户
*  @param id  
   * @param request  
   * 
*/ 
   @RequestMapping("getUser")
   public ModelAndView getUser(String username,ModelAndView mv) {
 
	   /*User user = userService.findById(id);*/
	   User user = userService.findByUserName(username);
	   mv.addObject("user", user);
	   mv.setViewName("updateuser");		
	
	   return mv;
	   
   }
   
   @RequestMapping("updateuser")
   public ModelAndView updateuser(HttpServletRequest req,User user, ModelAndView mv){	   
	   Map<String, String> map = new HashMap<String, String>();	   
	   map.put("username", req.getParameter("username"));       
	   /*User users = userService.findById(user.getId());*/
	   User users = userService.findByUserName(user.getUsername());
	   
	   try {		
		   if (users != null) {			   
			   if(user.getUsername().equals(users.getUsername())) {		   
				   mv.addObject("message", "用户名已存在！");
				   mv.setViewName("updateuser");			   
			   }  
		   }
		   else {				   
			   if (userService.update(user)) {
				   mv.addObject("message", "用户名修改成功！");
				   mv.setViewName("updateuser");
			   }
			   
		   }   
	} catch (Exception e) {
		
	}
	   return mv;
   }
   
   
   
   @RequestMapping("Keywordupdateuser")
   public ModelAndView Keywordupdateuser(HttpServletRequest req,User user, ModelAndView mv){	   
	   Map<String, String> map = new HashMap<String, String>();	   
	   map.put("username", req.getParameter("username"));       
	   User users = userService.findById(user.getId());
	   try {
		
		   if (users != null) {
			   
			   if(user.getUsername().equals(users.getUsername())) {		   
				   mv.addObject("error", "用户名已存在！");
				   mv.setViewName("updateuser");			   
			   } else {
				   
				   
				   if (userService.update(user)) {
					   List<User> userList = userService.findAll();		   
					   mv.addObject("userList",userList);
					   mv.setViewName("keyword");
				   }
				   
			   }    
		   }	  
	} catch (Exception e) {
		System.out.println(e);
	}
	   return mv;
   }
   /**  
    * 模糊查询
*  @param id  
   * @param request  
   * 
*/ 
   @RequestMapping("Keyword")
   public ModelAndView Keyword(@RequestParam(required=true,defaultValue="1") Integer page, HttpServletRequest request,ModelAndView mv,User user){  
	   
	   user.setUsername(request.getParameter("keyword"));
	   PageHelper.startPage(page, 3);
	   List<User> lists=userService.keywordfindAll(user);
	   System.out.println("查出的"+lists);
	   PageInfo<User> p=new PageInfo<User>(lists);
	   System.out.println(p);
	   mv.addObject("user", user);
	   mv.addObject("Keywordpage", p);
	   mv.addObject("userList", lists);
	   mv.setViewName("keyword");
       return mv;  
   } 
   /**  
    * 批量删除
*  @param id  
   * @param request  
   * 
*/ 
   @RequestMapping(value="/batchDelete")
   public ModelAndView batchDelete(String userList,ModelAndView mv){
       String[] strs = userList.split(",");
       for (int i = 0; i < strs.length; i++) {
           userService.delete(Integer.parseInt(strs[i])); 
       }
       mv.setViewName("manage");
       return mv;
   }
   @RequestMapping(value="/KeywordbatchDelete")
   public ModelAndView KeywordbatchDelete(String userList,ModelAndView mv){
       String[] strs = userList.split(",");
       for (int i = 0; i < strs.length; i++) {
           userService.delete(Integer.parseInt(strs[i])); 
       }
       mv.setViewName("keyword");
       return mv;
   }
   
   
//   查看当前登录的用户信息
   @RequestMapping("/selectUser")  
   public ModelAndView selectUser(@RequestParam(required=true,defaultValue="1") String username,ModelAndView mv){	   		
	   		User  user = userService.findByUserName(username);
	   		mv.addObject("user", user);
	   		mv.setViewName("active_user");	   
	   return mv;  
   
   }
   
// 查看当前用户的权限
 @RequestMapping("/RolesPremission")  
 public ModelAndView RolesPremission(int id,ModelAndView mv){
	   		URP urp = new URP();
	   		urp.setUserid(id);
	   		User user = userService.findById(id);
	   		urp.setUsername(user.getUsername());
	   		
	   		Set<String> roles = rolesService.findByRoles(user.getUsername());
	   		Set<String> permissions= permissionService.findByPermissions(user.getUsername());
   		
	   		
	   		urp.setRolesname(roles);
	   		urp.setPermissionname(permissions);		   		
	   		
	   		System.out.println("urp:"+urp);
	   		
	   		mv.addObject("urp", urp);
 	   		mv.setViewName("RolesPremission");	   
	   return mv;  
 
 }
   
}
  
	     
	     
	   
	 
   

