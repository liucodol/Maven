package com.ssm.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.LockedAccountException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.apache.shiro.crypto.SecureRandomNumberGenerator;
import org.apache.shiro.crypto.hash.SimpleHash;
import org.apache.shiro.subject.Subject;
import org.apache.shiro.util.ByteSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ssm.dao.IPermissionDao;
import com.ssm.pojo.Permission;
import com.ssm.pojo.Roles;
import com.ssm.pojo.URP;
import com.ssm.pojo.User;
import com.ssm.service.IPermissionService;
import com.ssm.service.IRolesService;
import com.ssm.service.IUserService;

import cn.itcast.estore.utils.MD5Utils;

@Controller
@RequestMapping("/permission")
public class permissionController {
		
	@Resource    
	private IUserService userService;
	@Resource    
	private IRolesService rolesService;
	@Resource    
	private IPermissionService permissionService;
	@Resource    
	private IPermissionDao permissionDao;
//	给指定用户添加权限
	@RequestMapping(value="/addPermission",method=RequestMethod.POST)
	public ModelAndView addPermission(@RequestParam("user_id") int user_id,/*@RequestParam(required=true) String permissionname,*/HttpServletRequest req,ModelAndView mv) {
		
		Boolean boolean1 = true;
		
		String permissionname=req.getParameter("permissionname");
		if(permissionname.equals("add")||permissionname.equals("del")||permissionname.equals("query")||permissionname.equals("update")) {
		Set<String> permissions = permissionService.findAll(user_id);
		
		for (String permission : permissions) {
			if(permission.equals(permissionname)) {				
				mv.addObject("error", "已拥有此权限！");
				mv.setViewName("permissionerror");	
				boolean1 = false;
			}			
		}
		
		if(boolean1) {
			Permission permission = permissionService.findByname(permissionname);
			permissionService.savePers(user_id,permission.getId());
			
			mv.addObject("success", "权限添加成功！");
			mv.setViewName("success");
		}
		}else {
			mv.addObject("error", "请正确填写权限（add，del，query，update）！");
			mv.setViewName("permissionerror");
		}
		return mv;

		
	}
	
	@RequestMapping("delPermission")
	   public void delPermission(int id,HttpServletRequest request,HttpServletResponse response){  

		
			   String result = "{\"result\":\"error\"}"; 	   
	       if(permissionService.delete(id)){  
	           result = "{\"result\":\"success\"}";  
	       }  
	       response.setContentType("application/json");  
	       try {  
	           PrintWriter out = response.getWriter();  
	           out.write(result);  
	       } catch (IOException e) {  
	           e.printStackTrace();  
	       }         

			
		
	   } 
	
	 
	   
	 
}
  
	     
	     
	   
	 
   

