package com.ssm.dao;

import java.util.List;
import java.util.Map;
import java.util.Set;


import com.ssm.pojo.User;


public interface IUserDao {
	/**
     * ��¼
     *
     * @param map
     * @return
     */
    /*public User login(Map<String, String> map);*/
    public User login(String username);
    /**
     * ע��
     *
     * @param map
     * @return
     */
	public User selectUser(Map<String, String> map);
	public void insertUser(User user);
	/**
     * ��ѯ���е��û�
     *
     * @param map
     * @return 
     */
	public List<User> findAll();
	/**
     * ������û�
     *
     * @param map
     * @return 
     */
	public void addUser(User user);
	/**
     * ɾ���û�
     *
     * @param map
     * @return 
     */
	public boolean delete(int id); 
	/**
     * �޸��û�
     *
     * @param map
     * @return 
     */
	public User findById(int id);
	public boolean update(User user);
	/**
     * �޸��û�
     *
     * @param map
     * @return 
     */	
	
	public List<User> keywordfindAll(User user);
	/**
     * 根据用户名查询用户
     *
     * @param map
     * @return 
     */
	public User findByUserName(String username);
	
	
	


	

}
