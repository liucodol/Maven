package com.ssm.dao;

import java.util.List;
import java.util.Set;

import org.apache.ibatis.annotations.Param;

import com.ssm.pojo.Roles;

public interface IRolesDao {

	List<Roles> findByRoles(int id);
	
	List<Roles> findAll(int id);
//	   给注册成功的用户添加角色（user）
	void insetRoles(int id);
//	删除用户时将拥有的角色也删除
	boolean delete(int id);

	Roles findById(String rolesname);

	void update(@Param("user_id")int user_id, @Param("id")int id);


	
	

	

	
}
