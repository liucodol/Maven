package com.ssm.dao;

import java.util.List;
import java.util.Set;

import com.ssm.pojo.Roles;

public interface IRolesDao {

	List<Roles> findByRoles(int id);
	
	List<Roles> findAll(int id); 

	
}
