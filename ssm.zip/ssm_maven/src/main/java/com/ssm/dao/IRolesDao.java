package com.ssm.dao;

import java.util.Set;

public interface IRolesDao {

	Set<String> findByRolesName(int id);

}
