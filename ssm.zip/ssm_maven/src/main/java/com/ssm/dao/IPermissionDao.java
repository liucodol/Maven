package com.ssm.dao;

import java.util.List;
import java.util.Set;

import org.apache.ibatis.annotations.Param;

import com.ssm.pojo.Permission;

public interface IPermissionDao {

	List<Permission> findByPermissions(int id);

	List<Permission> findAll(int user_id);


	void insert(int user_id, int id);


	Permission findByname(String permissionname);

	void savePers(@Param("user_id")int user_id,@Param("id")int id);

	boolean delete(int id);





	

}
