package com.ssm.dao;

import java.util.List;
import java.util.Set;

import com.ssm.pojo.Permission;

public interface IPermissionDao {

	List<Permission> findByPermissions(int id);

}
