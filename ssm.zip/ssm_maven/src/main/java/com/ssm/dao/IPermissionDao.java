package com.ssm.dao;

public interface IPermissionDao {

}
