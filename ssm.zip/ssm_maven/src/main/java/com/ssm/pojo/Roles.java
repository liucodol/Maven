package com.ssm.pojo;

import java.io.Serializable;

public class Roles implements Serializable{
	private int id;
	private String rolesname;
	@Override
	public String toString() {
		return "roles [id=" + id + ", rolesname=" + rolesname + "]";
	}
	public Roles(int id, String rolesname) {
		super();
		this.id = id;
		this.rolesname = rolesname;
	}
	public Roles() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getRolesname() {
		return rolesname;
	}
	public void setRolesname(String rolesname) {
		this.rolesname = rolesname;
	}
	
}
