package com.ssm.pojo;

import java.io.Serializable;

public class Permission implements Serializable{
	private int id;
	private String permissionname;
	@Override
	public String toString() {
		return "permission [id=" + id + ", permissionname=" + permissionname + "]";
	}
	public Permission(int id, String permissionname) {
		super();
		this.id = id;
		this.permissionname = permissionname;
	}
	public Permission() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPermissionname() {
		return permissionname;
	}
	public void setPermissionname(String permissionname) {
		this.permissionname = permissionname;
	}
	
}
