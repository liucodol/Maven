package com.ssm.service.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.ssm.dao.IPermissionDao;
import com.ssm.dao.IRolesDao;
import com.ssm.dao.IUserDao;
import com.ssm.pojo.Permission;
import com.ssm.pojo.Roles;
import com.ssm.pojo.User;
import com.ssm.service.IPermissionService;



@Service
public class PermissionServiceImpl implements IPermissionService{
	
	@Resource
	private IPermissionDao permissionDao;
	@Resource
	private IUserDao userDao;
	@Resource
	private IRolesDao rolesDao;
	
	public Set<String> findByPermissions(String username){
		Set<String> result = new HashSet<>();
		User user = userDao.findByUserName(username);

		List<Permission> permission = new ArrayList<>();		
		
			List<Permission> rps = permissionDao.findByPermissions(user.getId());
			permission.addAll(rps);

		for(Permission Per : permission) {
			result.add(Per.getPermissionname());
		}
		
		return result;
	}
	
	
	
	public Set<String> findAll(int user_id){
		
		Set<String> result = new HashSet<>();
		List<Permission> permission = new ArrayList<>();		
		
		List<Permission> rps = permissionDao.findAll(user_id);
		permission.addAll(rps);

	for(Permission Per : permission) {
		result.add(Per.getPermissionname());
	}
	return result;
	}
	
	
	public Permission findByname(String permissionname) {
		return permissionDao.findByname(permissionname);
		
	}
	
	public void savePers(int user_id, int id) {
		permissionDao.savePers(user_id, id);
	}
	
	
	public boolean delete(int id) {
		return permissionDao.delete(id);
		
	}
	public List<Permission> findByNameAll(int id) {  
        List<Permission> findAllList = permissionDao.findAll(id);  
        return findAllList;  
    } 
}
