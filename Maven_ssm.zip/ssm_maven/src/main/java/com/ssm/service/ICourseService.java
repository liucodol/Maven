package com.ssm.service;

import java.util.List;

import com.ssm.pojo.Course;

public interface ICourseService {

	List<Course> findAll();

	void insert(Course course);

}
