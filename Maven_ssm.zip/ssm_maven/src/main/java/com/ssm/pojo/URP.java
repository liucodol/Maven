package com.ssm.pojo;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

public class URP implements Serializable{
	private int userid;
	private String username;
	private Set<String> rolesname;
	private Set<String> permissionname;
	@Override
	public String toString() {
		return "URP [userid=" + userid + ", username=" + username + ", rolesname=" + rolesname + ", permissionname="
				+ permissionname + "]";
	}
	public URP(int userid, String username, Set<String> rolesname, Set<String> permissionname) {
		super();
		this.userid = userid;
		this.username = username;
		this.rolesname = rolesname;
		this.permissionname = permissionname;
	}
	public URP() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public Set<String> getRolesname() {
		return rolesname;
	}
	public void setRolesname(Set<String> rolesname) {
		this.rolesname = rolesname;
	}
	public Set<String> getPermissionname() {
		return permissionname;
	}
	public void setPermissionname(Set<String> permissionname) {
		this.permissionname = permissionname;
	}
	
}
