package com.ssm.pojo;

import java.sql.Timestamp;

import com.ssm.util.ExcelDesc;

public class Course {

	@ExcelDesc(value = "id" , orderBy = "1") 
    private Integer id;

	@ExcelDesc(value = "课程名称" , orderBy = "2") 
    private String coursename;


	@ExcelDesc(value = "老师编号" , orderBy = "3") 
    private Integer teacherid;


	@ExcelDesc(value = "教室编号" , orderBy = "4") 
    private Integer classroomid;

    /**
     * 
     */
	@ExcelDesc(value = "课程价钱" , orderBy = "5") 
    private Integer courseprice;

    /**
     * 
     */
	@ExcelDesc(value = "课程名额" , orderBy = "6") 
    private Integer courseplace;

    /**
     * 
     */
	@ExcelDesc(value = "课程数量" , orderBy = "7") 
    private String coursenum;

    /**
     * 
     */
	@ExcelDesc(value = "报名开始时间" , orderBy = "8") 
    private Timestamp  oldstarttime;


	@ExcelDesc(value = "报名结束时间" , orderBy = "9") 
    private Timestamp oldendtime;

  
	@ExcelDesc(value = "新生开始时间" , orderBy = "10") 
    private Timestamp newstarttime;


	@ExcelDesc(value = "新生结束时间" , orderBy = "11") 
    private Timestamp newendtime;


	@ExcelDesc(value = "老生优先报名  0 - 不开启 1 - 开启" , orderBy = "12") 
    private String isopenold;


	@ExcelDesc(value = "学生数量" , orderBy = "13") 
    private Integer studentnum;


	@ExcelDesc(value = "课程时长" , orderBy = "14") 
    private Integer courseduration;


	@ExcelDesc(value = "课程时间(周)" , orderBy = "15") 
    private String coursetimeweek;


	@ExcelDesc(value = "课程开始时间" , orderBy = "16") 
    private Timestamp coursestarttime;


	@ExcelDesc(value = "课程结束时间" , orderBy = "17") 
    private Timestamp courseendtime;

    /**
     * 
     */
	@ExcelDesc(value = "课程说明" , orderBy = "18") 
    private String remark;

    /**
     * 
     */
	@ExcelDesc(value = "课程最低年龄" , orderBy = "19") 
    private Integer courseage;

    /**
     * 
     */
	@ExcelDesc(value = "添加时间" , orderBy = "20") 
    private Timestamp createtime;

    /**
     * 
     */
	@ExcelDesc(value = "更改时间" , orderBy = "21") 
    private Timestamp updatetime;

    /**
     * 
     */
	@ExcelDesc(value = "科目编号" , orderBy = "22") 
    private Integer subjectid;

    /**
     * 
     */
	@ExcelDesc(value = "是否删除" , orderBy = "23") 
    private String isdel;

    /**
     * 
     */
	@ExcelDesc(value = "老课程编号" , orderBy = "24") 
    private Integer oldcourseid;

    /**
     * 
     */
	@ExcelDesc(value = "上课时间" , orderBy = "25") 
    private Timestamp sktime;

    /**
     * 
     */
	@ExcelDesc(value = "下课时间" , orderBy = "26") 
    private Timestamp xktime;

    /**
     * 
     */
	@ExcelDesc(value = "课程组" , orderBy = "27") 
    private String coursegroupimg;

	@Override
	public String toString() {
		return "Course [id=" + id + ", coursename=" + coursename + ", teacherid=" + teacherid + ", classroomid="
				+ classroomid + ", courseprice=" + courseprice + ", courseplace=" + courseplace + ", coursenum="
				+ coursenum + ", oldstarttime=" + oldstarttime + ", oldendtime=" + oldendtime + ", newstarttime="
				+ newstarttime + ", newendtime=" + newendtime + ", isopenold=" + isopenold + ", studentnum="
				+ studentnum + ", courseduration=" + courseduration + ", coursetimeweek=" + coursetimeweek
				+ ", coursestarttime=" + coursestarttime + ", courseendtime=" + courseendtime + ", remark=" + remark
				+ ", courseage=" + courseage + ", createtime=" + createtime + ", updatetime=" + updatetime
				+ ", subjectid=" + subjectid + ", isdel=" + isdel + ", oldcourseid=" + oldcourseid + ", sktime="
				+ sktime + ", xktime=" + xktime + ", coursegroupimg=" + coursegroupimg + "]";
	}

	public Course(Integer id, String coursename, Integer teacherid, Integer classroomid, Integer courseprice,
			Integer courseplace, String coursenum, Timestamp oldstarttime, Timestamp oldendtime, Timestamp newstarttime,
			Timestamp newendtime, String isopenold, Integer studentnum, Integer courseduration, String coursetimeweek,
			Timestamp coursestarttime, Timestamp courseendtime, String remark, Integer courseage, Timestamp createtime,
			Timestamp updatetime, Integer subjectid, String isdel, Integer oldcourseid, Timestamp sktime,
			Timestamp xktime, String coursegroupimg) {
		super();
		this.id = id;
		this.coursename = coursename;
		this.teacherid = teacherid;
		this.classroomid = classroomid;
		this.courseprice = courseprice;
		this.courseplace = courseplace;
		this.coursenum = coursenum;
		this.oldstarttime = oldstarttime;
		this.oldendtime = oldendtime;
		this.newstarttime = newstarttime;
		this.newendtime = newendtime;
		this.isopenold = isopenold;
		this.studentnum = studentnum;
		this.courseduration = courseduration;
		this.coursetimeweek = coursetimeweek;
		this.coursestarttime = coursestarttime;
		this.courseendtime = courseendtime;
		this.remark = remark;
		this.courseage = courseage;
		this.createtime = createtime;
		this.updatetime = updatetime;
		this.subjectid = subjectid;
		this.isdel = isdel;
		this.oldcourseid = oldcourseid;
		this.sktime = sktime;
		this.xktime = xktime;
		this.coursegroupimg = coursegroupimg;
	}

	public Course() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCoursename() {
		return coursename;
	}

	public void setCoursename(String coursename) {
		this.coursename = coursename;
	}

	public Integer getTeacherid() {
		return teacherid;
	}

	public void setTeacherid(Integer teacherid) {
		this.teacherid = teacherid;
	}

	public Integer getClassroomid() {
		return classroomid;
	}

	public void setClassroomid(Integer classroomid) {
		this.classroomid = classroomid;
	}

	public Integer getCourseprice() {
		return courseprice;
	}

	public void setCourseprice(Integer courseprice) {
		this.courseprice = courseprice;
	}

	public Integer getCourseplace() {
		return courseplace;
	}

	public void setCourseplace(Integer courseplace) {
		this.courseplace = courseplace;
	}

	public String getCoursenum() {
		return coursenum;
	}

	public void setCoursenum(String coursenum) {
		this.coursenum = coursenum;
	}

	public Timestamp getOldstarttime() {
		return oldstarttime;
	}

	public void setOldstarttime(Timestamp oldstarttime) {
		this.oldstarttime = oldstarttime;
	}

	public Timestamp getOldendtime() {
		return oldendtime;
	}

	public void setOldendtime(Timestamp oldendtime) {
		this.oldendtime = oldendtime;
	}

	public Timestamp getNewstarttime() {
		return newstarttime;
	}

	public void setNewstarttime(Timestamp newstarttime) {
		this.newstarttime = newstarttime;
	}

	public Timestamp getNewendtime() {
		return newendtime;
	}

	public void setNewendtime(Timestamp newendtime) {
		this.newendtime = newendtime;
	}

	public String getIsopenold() {
		return isopenold;
	}

	public void setIsopenold(String isopenold) {
		this.isopenold = isopenold;
	}

	public Integer getStudentnum() {
		return studentnum;
	}

	public void setStudentnum(Integer studentnum) {
		this.studentnum = studentnum;
	}

	public Integer getCourseduration() {
		return courseduration;
	}

	public void setCourseduration(Integer courseduration) {
		this.courseduration = courseduration;
	}

	public String getCoursetimeweek() {
		return coursetimeweek;
	}

	public void setCoursetimeweek(String coursetimeweek) {
		this.coursetimeweek = coursetimeweek;
	}

	public Timestamp getCoursestarttime() {
		return coursestarttime;
	}

	public void setCoursestarttime(Timestamp coursestarttime) {
		this.coursestarttime = coursestarttime;
	}

	public Timestamp getCourseendtime() {
		return courseendtime;
	}

	public void setCourseendtime(Timestamp courseendtime) {
		this.courseendtime = courseendtime;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getCourseage() {
		return courseage;
	}

	public void setCourseage(Integer courseage) {
		this.courseage = courseage;
	}

	public Timestamp getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Timestamp createtime) {
		this.createtime = createtime;
	}

	public Timestamp getUpdatetime() {
		return updatetime;
	}

	public void setUpdatetime(Timestamp updatetime) {
		this.updatetime = updatetime;
	}

	public Integer getSubjectid() {
		return subjectid;
	}

	public void setSubjectid(Integer subjectid) {
		this.subjectid = subjectid;
	}

	public String getIsdel() {
		return isdel;
	}

	public void setIsdel(String isdel) {
		this.isdel = isdel;
	}

	public Integer getOldcourseid() {
		return oldcourseid;
	}

	public void setOldcourseid(Integer oldcourseid) {
		this.oldcourseid = oldcourseid;
	}

	public Timestamp getSktime() {
		return sktime;
	}

	public void setSktime(Timestamp sktime) {
		this.sktime = sktime;
	}

	public Timestamp getXktime() {
		return xktime;
	}

	public void setXktime(Timestamp xktime) {
		this.xktime = xktime;
	}

	public String getCoursegroupimg() {
		return coursegroupimg;
	}

	public void setCoursegroupimg(String coursegroupimg) {
		this.coursegroupimg = coursegroupimg;
	}

	
}