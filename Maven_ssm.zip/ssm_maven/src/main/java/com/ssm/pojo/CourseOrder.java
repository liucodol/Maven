package com.ssm.pojo;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.ssm.util.ExcelDesc;

public class CourseOrder {
	@ExcelDesc(value = "编号" , orderBy = "1") 
    private Integer id;
	@ExcelDesc(value = "课程编号" , orderBy = "2")
    private Integer courseid;
	@ExcelDesc(value = "父母编号" , orderBy = "3")
    private Integer parentid;
	@ExcelDesc(value = "价格" , orderBy = "4")
    private Integer price;
	@ExcelDesc(value = "课程量" , orderBy = "5")
    private Integer coursenum;
	@ExcelDesc(value = "支付方式" , orderBy = "6")
    private String paytype;
	@ExcelDesc(value = "状态" , orderBy = "7")
    private String status;
	@ExcelDesc(value = "是否删除" , orderBy = "8")
    private String isdel;
	@ExcelDesc(value = "创建时间" , orderBy = "9")
    private Date createtime;
	@ExcelDesc(value = "更改时间", orderBy = "10")
    private Date updatetime;
	@ExcelDesc(value = "学生编号" , orderBy = "11")
    private Integer studentid;
	@ExcelDesc(value = "订单编号" , orderBy = "12")
    private String ordernum;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getCourseid() {
		return courseid;
	}
	public void setCourseid(Integer courseid) {
		this.courseid = courseid;
	}
	public Integer getParentid() {
		return parentid;
	}
	public void setParentid(Integer parentid) {
		this.parentid = parentid;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	public Integer getCoursenum() {
		return coursenum;
	}
	public void setCoursenum(Integer coursenum) {
		this.coursenum = coursenum;
	}
	public String getPaytype() {
		return paytype;
	}
	public void setPaytype(String paytype) {
		this.paytype = paytype;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getIsdel() {
		return isdel;
	}
	public void setIsdel(String isdel) {
		this.isdel = isdel;
	}
	public Date getCreatetime() {
		return createtime;
	}
	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}
	public Date getUpdatetime() {
		return updatetime;
	}
	public void setUpdatetime(Date updatetime) {
		this.updatetime = updatetime;
	}
	public Integer getStudentid() {
		return studentid;
	}
	public void setStudentid(Integer studentid) {
		this.studentid = studentid;
	}
	public String getOrdernum() {
		return ordernum;
	}
	public void setOrdernum(String ordernum) {
		this.ordernum = ordernum;
	}
	@Override
	public String toString() {
		return "CourseOrder [id=" + id + ", courseid=" + courseid + ", parentid=" + parentid + ", price=" + price
				+ ", coursenum=" + coursenum + ", paytype=" + paytype + ", status=" + status + ", isdel=" + isdel
				+ ", createtime=" + createtime + ", updatetime=" + updatetime + ", studentid=" + studentid
				+ ", ordernum=" + ordernum + "]";
		
		
		
	}
	public CourseOrder(Integer id, Integer courseid, Integer parentid, Integer price, Integer coursenum, String paytype,
			String status, String isdel, Date createtime, Date updatetime, Integer studentid, String ordernum) {
		super();
		this.id = id;
		this.courseid = courseid;
		this.parentid = parentid;
		this.price = price;
		this.coursenum = coursenum;
		this.paytype = paytype;
		this.status = status;
		this.isdel = isdel;
		this.createtime = createtime;
		this.updatetime = updatetime;
		this.studentid = studentid;
		this.ordernum = ordernum;
	}
	public CourseOrder() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	
	
	
    
    
    
}
