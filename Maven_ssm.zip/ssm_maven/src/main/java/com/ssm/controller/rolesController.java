package com.ssm.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.LockedAccountException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.apache.shiro.crypto.SecureRandomNumberGenerator;
import org.apache.shiro.crypto.hash.SimpleHash;
import org.apache.shiro.subject.Subject;
import org.apache.shiro.util.ByteSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ssm.pojo.Permission;
import com.ssm.pojo.Roles;
import com.ssm.pojo.URP;
import com.ssm.pojo.User;
import com.ssm.service.IPermissionService;
import com.ssm.service.IRolesService;
import com.ssm.service.IUserService;

import cn.itcast.estore.utils.MD5Utils;

@Controller
@RequestMapping("/roles")
public class rolesController {
		
	@Resource    
	private IUserService userService;
	@Resource    
	private IRolesService rolesService;
	@Resource    
	private IPermissionService permissionService;
	
	
	@RequestMapping(value="/updateRoles",method=RequestMethod.POST)
	public ModelAndView addPermission(@RequestParam("user_id") int user_id,HttpServletRequest req,ModelAndView mv) {
		String rolesname = req.getParameter("rolesname");
		Roles roles = rolesService.findById(rolesname);
		if(rolesname.equals("user")||rolesname.equals("manager")) {
		rolesService.update(user_id,roles.getId());
		
		mv.setViewName("success");
		}else {
			mv.addObject("error", "请正确输入角色名（user，manager）");
			mv.setViewName("roleserror");
		}
		return mv;

		
	}
}
  
	     
	     
	   
	 
   

