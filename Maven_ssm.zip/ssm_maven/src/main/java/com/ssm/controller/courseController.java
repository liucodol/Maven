package com.ssm.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.jstl.sql.Result;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ssm.pojo.Course;
import com.ssm.pojo.User;
import com.ssm.service.ICourseService;
import com.ssm.util.ExcelUtil;

@Controller
@RequestMapping("/course")
public class courseController {
	@Resource    
	private ICourseService courseService;
	
	
	@RequestMapping("/AllCourse")
	public ModelAndView AllCourse(@RequestParam(required=true,defaultValue="1") Integer page,ModelAndView mv) {
		
		PageHelper.startPage(page, 5);
		   List<Course> lists=courseService.findAll();
		   PageInfo<Course> p=new PageInfo<Course>(lists);
		   
		   mv.addObject("page", p);
		   mv.addObject("courseList", lists);
		mv.setViewName("course");
		return mv;
		
	}
	
//	导出为Excel
	@RequestMapping(value="/export") 
    public void excelProductList(HttpServletResponse response){  
		try { 			
        	List<Course> list =  courseService.findAll();  
        	ExcelUtil.exportExcel(list, "课程表", "清河少年宫", response, false);  
			
        	
		} catch (Exception e) {  
            e.printStackTrace();  
        }  
    }  
	 /** 
     * 导入Excel 
     */  
    @RequestMapping(value="/import",method=RequestMethod.POST)
    @ResponseBody 
    public String importProductExcel(@RequestParam(value = "excel") MultipartFile excel) {  
		 String msg = null;
		try {  
            ExcelUtil<Course> util = new ExcelUtil<Course>(Course.class);// 创建excel工具类  
            
            List<Course> list = util.importExcel(excel.getOriginalFilename(),"清河少年宫", excel.getInputStream());// 导出  
            if(list.size() > 0){  
            	
            	 for (Course course : list) {
					System.out.println(course);
					//插入数据库
					courseService.insert(course);
				}

            	 msg = "success";
            	 return msg;
            }  
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
        return msg;  
    }  
}
