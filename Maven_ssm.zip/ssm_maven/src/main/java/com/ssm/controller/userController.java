package com.ssm.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.LockedAccountException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.apache.shiro.crypto.SecureRandomNumberGenerator;
import org.apache.shiro.crypto.hash.SimpleHash;
import org.apache.shiro.subject.Subject;
import org.apache.shiro.util.ByteSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsRequest;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.exceptions.ServerException;
import com.aliyuncs.http.MethodType;
import com.aliyuncs.profile.DefaultProfile;
import com.aliyuncs.profile.IClientProfile;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ssm.pojo.Roles;
import com.ssm.pojo.URP;
import com.ssm.pojo.User;
import com.ssm.sdk.StaticPeram;
import com.ssm.service.IPermissionService;
import com.ssm.service.IRolesService;
import com.ssm.service.IUserService;

import cn.itcast.estore.utils.MD5Utils;

@Controller
@RequestMapping("/user")
public class userController {
		
	@Resource    
	private IUserService userService;
	@Resource    
	private IRolesService rolesService;
	@Resource    
	private IPermissionService permissionService;
	
  /**     
   * * 用户登录         
   * *      
   * * @param req     
   * * @param mv     
   * * @return     
   * */
   @RequestMapping("/login")
    public ModelAndView login(HttpServletRequest req,User user, ModelAndView mv,HttpSession session) {
     /*Map<String, String> map = new HashMap<String, String>();
     session.removeAttribute("message");
     try {
    	 if (user != null) {
    		 map.put("username", user.getUsername());       
    		 map.put("password", user.getPassword());
    		 User users = userService.login(map);
    		 String password = MD5Utils.md5(user.getPassword());
    		 System.out.println(password);
    		 if(users!=null) {
    			 if(users.getPassword().equals(password)) {
    				 //登录成功进入首页
    				session.setAttribute("message", user);
    				 mv.setViewName("home");
    			 }else {
//    					密码错误
    				 mv.addObject("message", "密码错误！！！");
    				 mv.setViewName("login");
    			 }	  
    		 }else {
//    			 告诉用户不存在
    			 mv.addObject("message", "用户不存在，请前往注册");
    			 mv.setViewName("login");
    		 }
    		 
    	 }else {
//    		用户名或者密码不能为空
    		 mv.addObject("message", "用户名或者密码不能为空，请重新输入");
    		 mv.setViewName("login");
    	 }
		
	} catch (Exception e) {
		// TODO: handle exception
	}*/
	   mv.addObject("user", user);
	   Subject subject = SecurityUtils.getSubject();
	/*   if (subject.isAuthenticated()) {*/
		
		UsernamePasswordToken token = new UsernamePasswordToken(user.getUsername(),user.getPassword());
		// 记住我
	/*	token.setRememberMe(true);*/
		mv.setViewName("home");
		try {			
			subject.login(token);
		} catch (UnknownAccountException e) {
			e.printStackTrace();
			mv.addObject("message", "用户名错误！");
			mv.setViewName("login");
		} catch (IncorrectCredentialsException e) {
			e.printStackTrace();
			mv.addObject("message", "密码错误！");
			mv.setViewName("login");
		} catch (LockedAccountException e) {
			e.printStackTrace();
			mv.addObject("message", "用户被锁定！");
			mv.setViewName("login");
		} catch (AuthenticationException  e) {
			e.printStackTrace();
			mv.addObject("message", "登录失败！");
			mv.setViewName("login");
		}
	/*}*/
    		 
        return mv;
}
   
   
   @RequestMapping(value="/logout")
	private ModelAndView Userlogout(ModelAndView mv) {
		
		mv.setViewName("login");
		
		return mv;
		
	}
   
   
   
   /**     
    * * 用户注册   
    * *      
    * * @param req     
    * * @param mv     
    * * @return     
    * */
   @RequestMapping("/register")
   public ModelAndView register(HttpServletRequest req,User user, ModelAndView mv){	   
	   Map<String, String> map = new HashMap<String, String>();
		//加密操作
		 String salt = new SecureRandomNumberGenerator().nextBytes().toString();	// 盐
		// 加盐次数	
		 int times = 2;	
			// MD5 加密
			String algorithmName = "md5";	
			// 加密 密码
			String encodedPassword = new SimpleHash(algorithmName, user.getPassword(), salt, times).toString();
	   map.put("username", req.getParameter("username"));       
/*	   map.put("password", encodedPassword);*/
	   
	   
	   User users = userService.selectUser(map);
	   
	   if (users != null) {
		   if(user.getUsername().equals(users.getUsername())) {		   
			   mv.addObject("error", "用户名已存在！");
			   mv.setViewName("register");
			   
		   }    
	   }else {
		   user.setPassword(encodedPassword);
		   user.setSalt(salt);
		   mv.addObject("success", "用户注册成功！");
		   userService.insertUser(user);
//		   给注册成功的用户添加角色（user）
		   User new_user = userService.selectUser(map);
		   rolesService.insetRoles(new_user.getId());
		   
		   mv.setViewName("register");
	   }	  
	   return mv;
   } 
   
  /**  
    *  获取所有用户列表  
    * @param request  
    * @return  
    */ 
   @RequestMapping("/Manage")  
   public ModelAndView userManage(@RequestParam(required=true,defaultValue="1") Integer page, HttpServletRequest request,ModelAndView mv){  
	   Subject subject =  SecurityUtils.getSubject(); 
	   
	   if(subject.hasRole("manager")){
		   
		   PageHelper.startPage(page, 3);
		   List<User> lists=userService.findAll();
		   PageInfo<User> p=new PageInfo<User>(lists);
		   
		   mv.addObject("page", p);
		   mv.addObject("userList", lists);
		   mv.setViewName("manage");
	   }else {
		   mv.setViewName("error");	   
		   
	}
	   return mv;
   } 
   
   /**  
             * 添加新用户  
    * @param request  
    * @return  
    */  
   @RequestMapping("/adduser")
   public ModelAndView addUser(HttpServletRequest req,User user, ModelAndView mv){	   

	
	   Map<String, String> map = new HashMap<String, String>();
	 //加密操作
		 String salt = new SecureRandomNumberGenerator().nextBytes().toString();	// 盐
		// 加盐次数	
		 int times = 2;	
			// MD5 加密
			String algorithmName = "md5";	
			// 加密 密码
			String encodedPassword = new SimpleHash(algorithmName, user.getPassword(), salt, times).toString();
	   map.put("username", req.getParameter("username"));       
	   map.put("password", encodedPassword);
	   User users = userService.selectUser(map);	   
	   if (users != null) {
		   if(user.getUsername().equals(users.getUsername())) {		   
			   mv.addObject("message", "用户名已存在！");
			   mv.setViewName("adduser");			   
		   }    
	   }else {
		   user.setPassword(encodedPassword);
		   user.setSalt(salt);
		   mv.addObject("message", "用户添加成功！");
		   userService.addUser(user);	
//		   给新添加的用户添加角色（user）
		   User new_user = userService.selectUser(map);
		   rolesService.insetRoles(new_user.getId());
		   
		   mv.setViewName("adduser");
	   }	

	   
	   return mv;
   }
   /**  
    * 删除用户  
*  @param id  
   * @param request  
   * @param response 
*/  
   @RequestMapping("delUser")
   public void delUser(int id,HttpServletRequest request,HttpServletResponse response){  

	
		   String result = "{\"result\":\"error\"}"; 	   
       if(userService.delete(id)){  
           result = "{\"result\":\"success\"}";  
       }  
       response.setContentType("application/json");  
       try {  
           PrintWriter out = response.getWriter();  
           out.write(result);  
       } catch (IOException e) {  
           e.printStackTrace();  
       }         

		
	
   }  
   /**  
    * 修改用户
*  @param id  
   * @param request  
   * 
*/ 
   @RequestMapping("getUser")
   public ModelAndView getUser(String username,ModelAndView mv) {
 
	   /*User user = userService.findById(id);*/
	   User user = userService.findByUserName(username);
	   mv.addObject("user", user);
	   mv.setViewName("updateuser");		
	
	   return mv;
	   
   }
   
   @RequestMapping("updateuser")
   public ModelAndView updateuser(HttpServletRequest req,User user, ModelAndView mv){	   
	   Map<String, String> map = new HashMap<String, String>();	   
	   map.put("username", req.getParameter("username"));       
	   /*User users = userService.findById(user.getId());*/
	   User users = userService.findByUserName(user.getUsername());
	   
	   try {		
		   if (users != null) {			   
			   if(user.getUsername().equals(users.getUsername())) {		   
				   mv.addObject("message", "用户名已存在！");
				   mv.setViewName("updateuser");			   
			   }  
		   }
		   else {				   
			   if (userService.update(user)) {
				   mv.addObject("message", "用户名修改成功！");
				   mv.setViewName("updateuser");
			   }
			   
		   }   
	} catch (Exception e) {
		
	}
	   return mv;
   }
   
   
   
   @RequestMapping("Keywordupdateuser")
   public ModelAndView Keywordupdateuser(HttpServletRequest req,User user, ModelAndView mv){	   
	   Map<String, String> map = new HashMap<String, String>();	   
	   map.put("username", req.getParameter("username"));       
	   User users = userService.findById(user.getId());
	   try {
		
		   if (users != null) {
			   
			   if(user.getUsername().equals(users.getUsername())) {		   
				   mv.addObject("error", "用户名已存在！");
				   mv.setViewName("updateuser");			   
			   } else {
				   
				   
				   if (userService.update(user)) {
					   List<User> userList = userService.findAll();		   
					   mv.addObject("userList",userList);
					   mv.setViewName("keyword");
				   }
				   
			   }    
		   }	  
	} catch (Exception e) {
		System.out.println(e);
	}
	   return mv;
   }
   /**  
    * 模糊查询
*  @param id  
   * @param request  
   * 
*/ 
   @RequestMapping("Keyword")
   public ModelAndView Keyword(@RequestParam(required=true,defaultValue="1") Integer page, HttpServletRequest request,ModelAndView mv,User user){  
	   
	   user.setUsername(request.getParameter("keyword"));
	   PageHelper.startPage(page, 3);
	   List<User> lists=userService.keywordfindAll(user);
	   System.out.println("查出的"+lists);
	   PageInfo<User> p=new PageInfo<User>(lists);
	   System.out.println(p);
	   mv.addObject("user", user);
	   mv.addObject("Keywordpage", p);
	   mv.addObject("userList", lists);
	   mv.setViewName("keyword");
       return mv;  
   } 
   /**  
    * 批量删除
*  @param id  
   * @param request  
   * 
*/ 
   @RequestMapping(value="/batchDelete")
   public ModelAndView batchDelete(String userList,ModelAndView mv){
       String[] strs = userList.split(",");
       for (int i = 0; i < strs.length; i++) {
           userService.delete(Integer.parseInt(strs[i])); 
       }
       mv.setViewName("manage");
       return mv;
   }
   @RequestMapping(value="/KeywordbatchDelete")
   public ModelAndView KeywordbatchDelete(String userList,ModelAndView mv){
       String[] strs = userList.split(",");
       for (int i = 0; i < strs.length; i++) {
           userService.delete(Integer.parseInt(strs[i])); 
       }
       mv.setViewName("keyword");
       return mv;
   }
   
   
//   查看当前登录的用户信息
   @RequestMapping("/selectUser")  
   public ModelAndView selectUser(@RequestParam(required=true,defaultValue="1") String username,ModelAndView mv){	   		
	   		User  user = userService.findByUserName(username);
	   		mv.addObject("user", user);
	   		mv.setViewName("active_user");	   
	   return mv;  
   
   }
   
// 查看当前用户的权限
 @RequestMapping("/RolesPremission")  
 public ModelAndView RolesPremission(int id,ModelAndView mv){
	   		URP urp = new URP();
	   		urp.setUserid(id);
	   		User user = userService.findById(id);
	   		urp.setUsername(user.getUsername());
	   		
	   		Set<String> roles = rolesService.findByRoles(user.getUsername());
	   		Set<String> permissions= permissionService.findByPermissions(user.getUsername());
   		
	   		
	   		urp.setRolesname(roles);
	   		urp.setPermissionname(permissions);		   		
	   		
	   		System.out.println("urp:"+urp);
	   		
	   		mv.addObject("urp", urp);
 	   		mv.setViewName("RolesPremission");	   
	   return mv;  
 
 }
 
 /**
	 * 阿里云短信服务配置
	 * @param mobile
	 * @return
	 */
    @RequestMapping(value="/mobile",method = RequestMethod.POST)
    @ResponseBody
	public  String getPhonemsg(String phone) {
    	String code ;
		/**
		 * 进行正则关系校验
		 */
		System.out.println(phone);
		if (phone == null || phone == "") {
			System.out.println("手机号为空");
			return "";
		}
		/**
		 * 短信验证---阿里大于工具
		 */

		// 设置超时时间-可自行调整
		System.setProperty(StaticPeram.defaultConnectTimeout, StaticPeram.Timeout);
		System.setProperty(StaticPeram.defaultReadTimeout, StaticPeram.Timeout);
		// 初始化ascClient需要的几个参数
		final String product = StaticPeram.product;// 短信API产品名称（短信产品名固定，无需修改）
		final String domain = StaticPeram.domain;// 短信API产品域名（接口地址固定，无需修改）
		// 替换成你的AK
		final String accessKeyId = StaticPeram.accessKeyId;// 你的accessKeyId,参考本文档步骤2
		final String accessKeySecret = StaticPeram.accessKeySecret;// 你的accessKeySecret，参考本文档步骤2
		// 初始化ascClient,暂时不支持多region
		IClientProfile profile = DefaultProfile.getProfile("cn-hangzhou",
				accessKeyId, accessKeySecret);
		try {
			DefaultProfile.addEndpoint("cn-hangzhou", "cn-hangzhou", product,domain);
		} catch (ClientException e1) {
			e1.printStackTrace();
		}
		
		//获取验证码
		code = vcode();
		
		IAcsClient acsClient = new DefaultAcsClient(profile);
		// 组装请求对象
		SendSmsRequest request = new SendSmsRequest();
		// 使用post提交
		request.setMethod(MethodType.POST);
		// 必填:待发送手机号。支持以逗号分隔的形式进行批量调用，批量上限为1000个手机号码,批量调用相对于单条调用及时性稍有延迟,验证码类型的短信推荐使用单条调用的方式
		request.setPhoneNumbers(phone);
		// 必填:短信签名-可在短信控制台中找到
		request.setSignName(StaticPeram.SignName);
		// 必填:短信模板-可在短信控制台中找到
		request.setTemplateCode(StaticPeram.TemplateCode);
		// 可选:模板中的变量替换JSON串,如模板内容为"亲爱的${name},您的验证码为${code}"时,此处的值为
		// 友情提示:如果JSON中需要带换行符,请参照标准的JSON协议对换行符的要求,比如短信内容中包含\r\n的情况在JSON中需要表示成\\r\\n,否则会导致JSON在服务端解析失败
		request.setTemplateParam("{ \"code\":\""+code+"\"}");
		// 可选-上行短信扩展码(无特殊需求用户请忽略此字段)
		// request.setSmsUpExtendCode("90997");
		// 可选:outId为提供给业务方扩展字段,最终在短信回执消息中将此值带回给调用者
		request.setOutId("yourOutId");
		// 请求失败这里会抛ClientException异常
		SendSmsResponse sendSmsResponse;
		try {
			sendSmsResponse = acsClient.getAcsResponse(request);
			if (sendSmsResponse.getCode() != null && sendSmsResponse.getCode().equals("OK")) {
				// 请求成功
				System.out.println("获取验证码成功！！！");
				
			} else { 
				//如果验证码出错，会输出错误码告诉你具体原因
				System.out.println(sendSmsResponse.getCode());
				System.out.println("获取验证码失败...");
				
			}
		} catch (ServerException e) {
			e.printStackTrace();
			return "由于系统维护，暂时无法注册！！！";
		} catch (ClientException e) {
			e.printStackTrace();
			return "由于系统维护，暂时无法注册！！！";
		}
		return code;
	}	
    /**
     * 生成6位随机数验证码
     * @return
     */
    public static String vcode(){
    	String vcode = "";
    	for (int i = 0; i < 6; i++) {
    		vcode = vcode + (int)(Math.random() * 9);
    	}
    	return vcode;
    }	

   
}
  
	     
	     
	   
	 
   

