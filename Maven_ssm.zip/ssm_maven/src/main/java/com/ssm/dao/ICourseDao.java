package com.ssm.dao;

import java.util.List;

import com.ssm.pojo.Course;

public interface ICourseDao {

	List<Course> findAll();

	void insert(Course course);

}
